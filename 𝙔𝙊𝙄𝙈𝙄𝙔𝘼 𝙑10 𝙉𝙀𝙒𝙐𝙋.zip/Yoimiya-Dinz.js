// RECODE BY DINZID VyL (recode)
// ©  Recode BY DinzID Vyl 2022 - 2025
// © DanzNano (pemilik base )
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

"Yoimiya - MD" /// JANGAN DI UBAH NANTI ERROR
//𝙎𝘾 𝙄𝙉𝙄 𝙁𝙍𝙀𝙀 100% 𝙆𝘼𝙇𝙊 𝘼𝘿𝘼 𝙔𝘼𝙉𝙂 𝙉𝙂𝙀𝙅𝙐𝘼𝙇 𝘽𝙀𝙎𝙊𝙆 𝙈𝘼𝙈𝘼𝙆𝙉𝙔𝘼 𝙈𝘼𝙏𝙄

TQTO
© BASE DanzNano Official 
- DinzID (  YOIMIYA  )
- Ditss ( Asuma)
- FlowFalcon 
- Velyn VIST
- Skyz
- Siputz
- Shanz

Base
- Cheems Xeon
- © DanzNano


𝐑𝐎𝐎𝐌 𝐂𝐇𝐀𝐓: 'https://chat.whatsapp.com/Gv1gsvCBiukEBpaRQ4qDSO',
𝐂𝐇 𝐎𝐑𝐈 𝐘𝐎𝐈𝐌𝐈𝐘𝐀: 'https://whatsapp.com/channel/0029VazsM78H5JM1Rbn18I0s'
//DILARANG HAPUS CREDITS 
© BASE DanzNano
#recode by dinzid
footer '© DinzID VyL | Yoimiya - MD'
